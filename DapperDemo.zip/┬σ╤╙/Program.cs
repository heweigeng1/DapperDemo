﻿using Dapper.Data;
using LibraryCreateDatabase;
using LibraryCreateDatabase.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Linq;

namespace 洛延
{
    class Program
    {
        static void Main(string[] args)
        {
            var users = new DataUtils().Execute();
            foreach (var item in users)
            {
                Console.WriteLine(item.PhoneNum);
            }
            using (var db = new InitContext())
            {

                db.Users.Add(new User
                {
                    Id = Guid.NewGuid(),
                    PhoneNum = "112121212",
                    UserName = "老猫"
                });
                db.SaveChanges();
               var user= db.Users.FirstOrDefault();
                Console.WriteLine(user.UserName);
                Console.ReadKey();
            }
        }
    }
}
